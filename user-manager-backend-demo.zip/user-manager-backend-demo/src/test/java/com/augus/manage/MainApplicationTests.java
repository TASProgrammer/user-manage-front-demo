package com.augus.manage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 主类测试
 *
 * @author <a href="https://github.com/jhaugus">蓝花晨月夕</a>
 * 
 */
@SpringBootTest
class MainApplicationTests {

    @Test
    void contextLoads() {
    }

}
